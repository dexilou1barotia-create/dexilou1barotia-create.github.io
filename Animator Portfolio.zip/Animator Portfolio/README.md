# Dexilou Dizon Barotia | Animator Portfolio

Aspiring animator and BSIT (Programming) student at the Polytechnic University of the Philippines, Calauan Campus. I make traditional hand-drawn 2D animation, digital 2D animation, and 3D modeling and animation.

## Portfolio Website

https://dexilou1barotia-create.github.io

Built with HTML, CSS, and JavaScript and hosted on GitHub Pages.

## Resume

[Download Resume (PDF)](Dexilou_Barotia_Resume.pdf)

## GitHub Repository

- [Animation-Projects](https://github.com/dexilou1barotia-create/Animation-Projects) - Animation projects

## Contact

- Email: dexilou1.barotia@gmail.com
- GitHub: https://github.com/dexilou1barotia-create

## Animation Videos (Google Drive)

1. [Animation 1](https://drive.google.com/file/d/1SgsiLILx0V_bKN2FW0_2uagMDXjDAyW2/view?usp=sharing)
2. [Animation 2](https://drive.google.com/file/d/1-MrChaLwdNyPLjlQLV94vHOX5zKmc-R8/view?usp=sharing)
3. [Animation 3](https://drive.google.com/file/d/1-hh0upKaC5C38gCdmi6UV9RrM_MYWJ_F/view?usp=sharing)
4. [Animation 4](https://drive.google.com/file/d/1-_8le4wab33gKt2WUc_L8IQ6T8wjkt6t/view?usp=sharing)
5. [Animation 5](https://drive.google.com/file/d/1-QH2QKUfwyxE9XV-1SRpTDgE_SAosddJ/view?usp=sharing)
6. [Animation 6](https://drive.google.com/file/d/101SiRCEgJVPh2_GT3rl9tCEKw8VF9ElL/view?usp=sharing)
7. [Animation 7](https://drive.google.com/file/d/1-5ADOFR0hO4zhBuJXK0erCxBa_dRqmF-/view?usp=sharing)
8. [Animation 8](https://drive.google.com/file/d/1-An5fL2EoEdWWZ2nL7jzMhUfjh29lybu/view?usp=sharing)

## Traditional Hand-Drawn Art (Google Drive)

<details>
<summary>Click to view all 39 drawings</summary>

1. [Hand-Drawn Artwork 1](https://drive.google.com/file/d/1KKuNMD6YZ_OLs2hKDxhX_H2PQem6Q7zw/view?usp=sharing)
2. [Hand-Drawn Artwork 2](https://drive.google.com/file/d/12E6t8kADb5E0I3oFJWcq7-fO-4Sgt8FK/view?usp=sharing)
3. [Hand-Drawn Artwork 3](https://drive.google.com/file/d/1D2W8A18ONhJUt_NufmFTHyZIldrkjR4X/view?usp=sharing)
4. [Hand-Drawn Artwork 4](https://drive.google.com/file/d/1491QoVjMm-gJUcWGtuq3Vj1NtXKdGs0F/view?usp=sharing)
5. [Hand-Drawn Artwork 5](https://drive.google.com/file/d/1ISXH38Y9zHD-bHVjYOn0P8gaSSTLSGIz/view?usp=sharing)
6. [Hand-Drawn Artwork 6](https://drive.google.com/file/d/16CaxrCZxTXZIOdoSjTWIpPLEc7-Rvm7t/view?usp=sharing)
7. [Hand-Drawn Artwork 7](https://drive.google.com/file/d/1BOnryTMOSXwM1mcmZroWVVFtZulK3hru/view?usp=sharing)
8. [Hand-Drawn Artwork 8](https://drive.google.com/file/d/14rjG1uU6xxXbLTIJEFWcqRN936QUN7zc/view?usp=sharing)
9. [Hand-Drawn Artwork 9](https://drive.google.com/file/d/1J7Q_w7EPausFOOWDao2fhvDM9tPHPxTh/view?usp=sharing)
10. [Hand-Drawn Artwork 10](https://drive.google.com/file/d/1y69qNtdstjSiwVABEL-e14i3BhDGbTcN/view?usp=sharing)
11. [Hand-Drawn Artwork 11](https://drive.google.com/file/d/1UaRcU92FavG3SCJ4Wg83Z_XxolwI145x/view?usp=sharing)
12. [Hand-Drawn Artwork 12](https://drive.google.com/file/d/1VEXJ6wYQl75ga5CU4cthyG_8J1e2tBBd/view?usp=sharing)
13. [Hand-Drawn Artwork 13](https://drive.google.com/file/d/1Zh1W_34BAScLlFwuLT4NZwvpW2f9SLhy/view?usp=sharing)
14. [Hand-Drawn Artwork 14](https://drive.google.com/file/d/1wKCSdddSfjXnAEKfmdUq_4euqEyzZpJR/view?usp=sharing)
15. [Hand-Drawn Artwork 15](https://drive.google.com/file/d/1T5Kri1pzYWmWD31e5IANAj-CVt3oy_rH/view?usp=sharing)
16. [Hand-Drawn Artwork 16](https://drive.google.com/file/d/1DI-aYT5MuH1PTUmDg_OTyVIxgpIZqFC/view?usp=sharing)
17. [Hand-Drawn Artwork 17](https://drive.google.com/file/d/1GgbUGS6WcDx9WkewlRjleyoAcxTbJQXu/view?usp=sharing)
18. [Hand-Drawn Artwork 18](https://drive.google.com/file/d/1zGPCJA17d1F5bU-vcJtjUnxdMGci63hH/view?usp=sharing)
19. [Hand-Drawn Artwork 19](https://drive.google.com/file/d/1EuI4LYCeik7yoBs_JpyhZf6QXUOpHPET/view?usp=sharing)
20. [Hand-Drawn Artwork 20](https://drive.google.com/file/d/1YlVRoyLI8IoHmPppJ00CpSsOPmguALiT/view?usp=sharing)
21. [Hand-Drawn Artwork 21](https://drive.google.com/file/d/1FYGGMD-j_b0uxSqUJuItzSK8qbdWu8Vp/view?usp=sharing)
22. [Hand-Drawn Artwork 22](https://drive.google.com/file/d/1jwgsA5ZaPCEx5uzn6cO5BRcb556kCcFf/view?usp=sharing)
23. [Hand-Drawn Artwork 23](https://drive.google.com/file/d/1NCZ7Vmp_No5aZwQHvf44tFhTOXJAZ9sd/view?usp=sharing)
24. [Hand-Drawn Artwork 24](https://drive.google.com/file/d/10XzO5QCYsCkwy3WqWOaSrtsi8HqS8TIp/view?usp=sharing)
25. [Hand-Drawn Artwork 25](https://drive.google.com/file/d/1Shqbm2_1neHs1HSNljUFtF0djqVZ31K9/view?usp=sharing)
26. [Hand-Drawn Artwork 26](https://drive.google.com/file/d/1-Xd69JSphAxComdTkvlIftVIzgmQ6YnT/view?usp=sharing)
27. [Hand-Drawn Artwork 27](https://drive.google.com/file/d/1xurAV0E7WnIRkAx2yvTmIcocZddtNLnc/view?usp=sharing)
28. [Hand-Drawn Artwork 28](https://drive.google.com/file/d/16KUPZ8gQiTgpZlVY33jWv1fVfaluiFUU/view?usp=sharing)
29. [Hand-Drawn Artwork 29](https://drive.google.com/file/d/1hT5x0Nb6mYePa5yHOeBkxWghF6nMhKMH/view?usp=sharing)
30. [Hand-Drawn Artwork 30](https://drive.google.com/file/d/157KBC5IrcflMhdwr2HuUe5keK4ryflkI/view?usp=sharing)
31. [Hand-Drawn Artwork 31](https://drive.google.com/file/d/1bG8G82BBvKCj05PYzFpaZm0nxPxeYopt/view?usp=sharing)
32. [Hand-Drawn Artwork 32](https://drive.google.com/file/d/1VheewJWfft5gZxOR3IRnXcB9iKnVMxrf/view?usp=sharing)
33. [Hand-Drawn Artwork 33](https://drive.google.com/file/d/1jh7wZcl6ye0nUrdBTRnZgl9xPfG_eDrr/view?usp=sharing)
34. [Hand-Drawn Artwork 34](https://drive.google.com/file/d/1hAOjJkl4uvWEU1CV5I7-uGWw4ltEz58p/view?usp=sharing)
35. [Hand-Drawn Artwork 35](https://drive.google.com/file/d/1iP4lzq7MsdCyeFT_lk78XIzdvw2BidrU/view?usp=sharing)
36. [Hand-Drawn Artwork 36](https://drive.google.com/file/d/1I0E5IHoEry7LbKkd_QKVVJRTwwOoqno8/view?usp=sharing)
37. [Hand-Drawn Artwork 37](https://drive.google.com/file/d/1HbXeOig6TmeRYtDAy1M-gwXLQmien73x/view?usp=sharing)
38. [Hand-Drawn Artwork 38](https://drive.google.com/file/d/1kbw_XBtKQa3W0jnupXukoEnACQhzqpE_/view?usp=sharing)
39. [Hand-Drawn Artwork 39](https://drive.google.com/file/d/1gYwrHLjPgv223RRKmVrgmdaMdSIamf3k/view?usp=sharing)

</details>

## Tools

FlipaClip, 3D modeling software, HTML, CSS, JavaScript, GitHub Pages
